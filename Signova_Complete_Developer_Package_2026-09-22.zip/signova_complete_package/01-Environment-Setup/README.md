# 01 - Environment Setup (Odoo 18)

## Requirements
- Docker + Docker Compose
- 4GB RAM, 10GB disk
- Ports 8069 free

## Quick Start (fresh)
```bash
cd odoo17-theme-test
sudo docker compose down -v
rm -rf ./addons; mkdir -p ./addons
# copy theme zip to ./addons via steps below
sudo docker compose up -d
sudo docker compose logs -f --tail=30 web  # wait for "HTTP service (werkzeug) running on 0.0.0.0:8069"
# Open http://localhost:8069 → Create DB signova_test (☑ Demo data)
```

## Verify
```bash
sudo docker compose ps
sudo docker compose logs --tail=20 web
curl -I http://localhost:8069
```

## Versions
- Odoo: 18.0-20260908
- Postgres: 15
- Theme: 18.0.5.2.x (see 02 and 03)
