#!/bin/bash
set -e
echo "=== Restarting Odoo Docker (keep DB) ==="
sudo docker compose restart web
sudo docker compose logs --tail=20 web
echo "=== For full fresh restart (WIPES DB) ==="
echo "sudo docker compose down -v && sudo docker compose up -d"
