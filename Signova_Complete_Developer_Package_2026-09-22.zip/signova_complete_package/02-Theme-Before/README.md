# 02 - Theme BEFORE (original)

This is the theme as initially shared (v18.0.5.2.0) — before Odoo 18 compatibility fixes.

- File: signova_ecommerce_theme_v18.0.5.2.0.zip
- Issues on Odoo 18: 
  - `//header//div[hasclass('o_wsale_my_cart')]` not found
  - `//div[@id='product_detail']` not found
  - `<data>` wrapper validation errors
  - `label` without `for`

Use this to show "before" state. Install this first, verify shop works, then upgrade to 03.

Install:
```bash
unzip -o signova_ecommerce_theme_v18.0.5.2.0.zip -d /tmp/
sudo rm -rf ./addons/signova_ecommerce_theme
sudo cp -r /tmp/signova_ecommerce_theme ./addons/
sudo chown -R 1000:1000 ./addons; sudo chmod -R 755 ./addons
sudo docker compose restart web
# Apps → Update Apps List → Install
```
