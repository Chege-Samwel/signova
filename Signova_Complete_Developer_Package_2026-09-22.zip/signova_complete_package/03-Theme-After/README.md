# 03 - Theme AFTER (fixed, seamless upgrade)

This is the fixed theme for Odoo 18 (v18.0.5.2.10) — all install blockers patched.

- File: signova_ecommerce_theme_v18.0.5.2.10.zip
- Fixes:
  - `product_data_views.xml`: minimal, label `for="signova_specs_json"`, no notebook value on product.template
  - `website_templates.xml`: `//header → //header`, `//div[@id='product_detail'] → //div[@id='wrap']`, shop grid fallback
  - All `views/*.xml` stripped `<data>` wrapper for Odoo 18 RelaxNG
  - `faq_page` + `homepage` correctly handled
  - Version bump 18.0.5.2.10

Upgrade from BEFORE:
```bash
unzip -o signova_ecommerce_theme_v18.0.5.2.10.zip -d /tmp/
sudo rm -rf ./addons/signova_ecommerce_theme
sudo cp -r /tmp/signova_ecommerce_theme ./addons/
sudo chown -R 1000:1000 ./addons; sudo chmod -R 755 ./addons
sudo docker compose restart web
# Apps → Update Apps List → Upgrade (or shell: odoo -u signova_ecommerce_theme)
```

Verify: Apps shows 18.0.5.2.10, http://localhost:8069/shop works, no 500.

This is the zip to send to production developer.
