# 04 - Demo Data

Adds realistic data across Inventory, Website, Sales for theme testing.

- 30 storable products (Signova Electronics category, 3k-90k QAR, 20-100 stock)
- 10 sales orders (5 confirmed, 5 draft)
- Published to website shop

## Run AFTER theme installed
```bash
sudo docker compose exec -T web odoo shell -d signova_test --db_host=db --db_user=odoo --db_password=odoo < 04-Demo-Data/add_data.py
# Check:
# Inventory → Products → 30
# Sales → Orders → 10 (S000xx)
# http://localhost:8069/shop → grid
```

If `is_published` error, ensure theme/website_sale installed first.
