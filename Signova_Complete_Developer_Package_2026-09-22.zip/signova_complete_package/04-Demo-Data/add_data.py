# Odoo 18 demo data — 30 products + stock + 10 orders (5 confirmed)
# Run AFTER theme installed (needs website_sale fields)
# Usage: sudo docker compose exec -T web odoo shell -d signova_test --db_host=db --db_user=odoo --db_password=odoo < add_data.py
cat = env['product.category'].search([('name','=','Signova Electronics')], limit=1) or env['product.category'].create({'name':'Signova Electronics'})
import random
names=["Smart TV 55\"","Soundbar 2.1","Wireless Earbuds","Phone 128GB","Laptop 14\"","Tablet","Smart Watch","Speaker","Router WiFi6","Camera 4K"]
for i in range(30):
    n=f"Signova {random.choice(names)} #{i+1}"
    if env['product.template'].search([('name','=',n)],limit=1): continue
    vals={'name':n,'categ_id':cat.id,'list_price':random.randint(3000,90000),'sale_ok':True}
    if 'is_published' in env['product.template']._fields: vals['is_published']=True
    if 'website_published' in env['product.template']._fields: vals['website_published']=True
    t=env['product.template'].create(vals)
    if 'is_storable' in env['product.template']._fields: t.is_storable=True
    loc=env['stock.location'].search([('usage','=','internal')],limit=1)
    env['stock.quant'].with_context(inventory_mode=True).create({'product_id':t.product_variant_id.id,'location_id':loc.id,'inventory_quantity':random.randint(20,100)}).action_apply_inventory()
    print(f"Created {n}")
print("DONE products")
partner=env['res.partner'].search([('is_company','=',True)],limit=1) or env['res.partner'].create({'name':'Test Customer','is_company':True})
prods=env['product.product'].search([('sale_ok','=',True)],limit=10)
for o in range(10):
    so=env['sale.order'].create({'partner_id':partner.id,'order_line':[(0,0,{'product_id':random.choice(prods).id,'product_uom_qty':random.randint(1,3)}) for _ in range(2)]})
    if o<5: so.action_confirm()
    print(f"SO {so.name}")
print("DONE orders")
