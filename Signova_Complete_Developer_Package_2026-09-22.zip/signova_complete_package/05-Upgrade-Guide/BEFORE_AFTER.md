# BEFORE vs AFTER

| Area | BEFORE (2.0) | AFTER (2.10) |
|------|--------------|--------------|
| Install on Odoo 18 | Fails: `o_wsale_my_cart` not found, `product_detail` not found, `data` extra content | Succeeds: xpaths → `//header`, `//div[@id='wrap']`, no `<data>` wrapper |
| Product form | `Field value` error, label without `for` | Minimal view, label `for="signova_specs_json"`, no notebook |
| Shop | 500 if installed | Works |
| Version | 18.0.5.2.0 | 18.0.5.2.10 |

Screenshots to take:
1. BEFORE: http://localhost:8069/shop (after 2.0 install)
2. AFTER: same URL after 2.10 upgrade — hero, grid, product page
3. Apps before/after version
4. Inventory/Sales counts before/after (should stay 30/10)
