# 05 - Upgrade Guide (BEFORE → AFTER)

## For Local Test (keep DB)
```bash
cd ~/git\ projects/odoo17-theme-test
ls -lh new.zip; unzip -p new.zip signova_ecommerce_theme/__manifest__.py | grep version
# → 18.0.5.2.10
sudo rm -rf /tmp/signova_ecommerce_theme; unzip -o new.zip -d /tmp/
sudo rm -rf ./addons/signova_ecommerce_theme
sudo cp -r /tmp/signova_ecommerce_theme ./addons/
sudo chown -R 1000:1000 ./addons; sudo chmod -R 755 ./addons
sudo docker compose restart web
# then Apps → Update Apps List → Update → Signova → Upgrade
# or shell: sudo docker compose exec -T web odoo -u signova_ecommerce_theme -d signova_test --db_host=db --db_user=odoo --db_password=odoo --stop-after-init
```

## For Production Developer
Same 5 steps, with production paths:
```bash
unzip -o signova_ecommerce_theme_v18.0.5.2.10.zip -d /tmp/
sudo rm -rf $ADDONS/signova_ecommerce_theme
sudo cp -r /tmp/signova_ecommerce_theme $ADDONS/
sudo chown -R odoo:odoo $ADDONS/signova_ecommerce_theme
sudo systemctl restart odoo
# Odoo Apps → Update Apps List → Upgrade
```

## Verification
- `unzip -l new.zip | head` → top-level `signova_ecommerce_theme/`
- `grep version __manifest__.py` → 18.0.5.2.10
- `http://localhost:8069/shop` → 200, no 500
- `Apps` → 18.0.5.2.10 Installed
- `Inventory`, `Sales`, `Website` data intact

## Rollback
```bash
sudo rm -rf ./addons/signova_ecommerce_theme
sudo cp -r ./addons/signova_ecommerce_theme.bak ./addons/signova_ecommerce_theme  # if you backed up
sudo docker compose restart web
```
