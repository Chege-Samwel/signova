# 06 - Features (All Enabled)

- **Theme**: Odoo 18 compatible, navy/gold, hero 1900x550, sticky bar, lightbox
- **Product Data**: signova_short_desc, long_desc, specs JSON, care, delivery, SEO, specs table, FAQs (30), hooks scoped to signova website only
- **Shop**: 5 desktop / 3 mobile grid, filters, cart, wishlist, compare
- **Inventory**: Stock quants, 30 demo products
- **Sales**: 10 orders, pricelists, delivery
- **Website**: FAQ page, homepage marketplace, SEO meta, sitemap

All features verified on Odoo 18 with demo data — no 500, seamless upgrade, DB preserved.

## To show developer
1. Environment Setup (01)
2. Install BEFORE (02) → screenshot
3. Add demo data (04) → show Inventory/Sales/Website
4. Upgrade to AFTER (03 via 05) → show same data intact + new theme
5. Verify logs (07)

