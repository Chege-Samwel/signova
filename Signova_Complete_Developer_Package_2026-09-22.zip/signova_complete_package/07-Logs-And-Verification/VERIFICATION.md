# 07 - Verification

## Commands
```bash
sudo docker compose ps
sudo docker compose logs --tail=20 web
unzip -p new.zip signova_ecommerce_theme/__manifest__.py | grep version
unzip -l new.zip | head
curl -I http://localhost:8069/shop
sudo docker compose exec db psql -U odoo -c "select name,version from ir_module_module where name='signova_ecommerce_theme';"
```

## Expected
- `version: 18.0.5.2.10`
- `signova_ecommerce_theme/` top-level
- No `Element odoo has extra content` in logs after 2.10
- `HTTP service (werkzeug) running on 0.0.0.0:8069`
- Shop 200

## Share to developer
Zip this entire folder: `Signova_Complete_Developer_Package_2026-09-22.zip`
Include this VERIFICATION.md + logs.
