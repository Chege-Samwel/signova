{
    'name': 'Signova E-commerce Theme',
    'version': '18.0.5.2.0',
    'category': 'Website/Website',
    'summary': 'Signova-only storefront customizations, isolated from Euromedia',
    'description': """
Signova E-commerce Theme
=========================
Website-specific look and feel for the Signova storefront (signova.store).

Same database, same Odoo instance as Euromedia. This module NEVER touches
Euromedia's website. Every template override and every static asset is
scoped to the Signova website record only, via the website_id field.
There is no global override of website.layout, website_sale, or any other
shared controller/template.

How the isolation works
------------------------
1. Every ir.ui.view record this module creates has website_id set to the
   Signova website, assigned automatically on install (post_init_hook) by
   looking up the website via its domain/name — no manual step, no
   hardcoded database ID.
2. Every template additionally guards its content with
   `t-if="website and website.id == ..."` as a second line of defense, so
   even if website_id scoping were ever misconfigured, nothing renders on
   another site.
3. CSS/JS are registered as ir.asset records (not manifest-level
   web.assets_frontend entries), which support website_id natively. All
   selectors are additionally namespaced under `.o_signova_theme`, a body
   class only applied on the Signova site.

Nothing here modifies euromedia's theme module, views, or assets.
""",
    'author': 'Signova',
    'website': 'https://signova.store',
    'license': 'LGPL-3',
    'depends': ['website_sale', 'product'],
    'data': [
        'security/ir.model.access.csv',
        'views/product_data_views.xml',
        'views/website_templates.xml',
        'views/homepage_marketplace.xml',
        'views/faq_page.xml',
        'data/assets.xml',
        'data/faqs.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'post_init_hook': 'post_init_hook',
}
