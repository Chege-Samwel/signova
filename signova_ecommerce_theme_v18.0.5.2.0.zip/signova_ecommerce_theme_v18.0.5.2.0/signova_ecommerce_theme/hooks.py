import logging

_logger = logging.getLogger(__name__)

# xml_id (without module prefix) -> nothing needed, we just scope
# every record this module ships to the Signova website.
# IMPORTANT: every new template/asset added to this module MUST be listed
# here, otherwise its website_id stays False (= global) and it will render
# on the Euromedia storefront too.
RECORDS_TO_SCOPE = [
    'homepage_signova_banner',
    'header_signova_signin',
    'body_signova_class',
    'shop_signova_grid_tweak',
    'product_signova_gallery',
    'product_signova_sticky_cta',
    'seo_signova_head',
    'homepage_signova_marketplace',
    'signova_product_card',
    'asset_signova_scss',
    'asset_signova_js',
]

MODULE = 'signova_ecommerce_theme'


def _find_signova_website(env):
    Website = env['website']
    # Prefer an exact domain match, fall back to name match.
    website = Website.search([('domain', 'ilike', 'signova.store')], limit=1)
    if not website:
        website = Website.search([('name', 'ilike', 'signova')], limit=1)
    return website


def post_init_hook(env):
    """Odoo 17/18 style hook: receives an Environment directly.

    If your Odoo version still calls hooks as post_init_hook(cr, registry),
    replace the signature with:
        def post_init_hook(cr, registry):
            env = api.Environment(cr, SUPERUSER_ID, {})
    """
    website = _find_signova_website(env)

    if not website:
        _logger.warning(
            "signova_ecommerce_theme: could not find a website matching "
            "domain 'signova.store' or name 'Signova'. No view/asset was "
            "scoped automatically — go to Website > Configuration > "
            "Settings, and for each view/asset shipped by this module, "
            "set its Website field to Signova manually, or re-run this "
            "hook once the Signova website record exists."
        )
        return

    for record_name in RECORDS_TO_SCOPE:
        xmlid = f"{MODULE}.{record_name}"
        record = env.ref(xmlid, raise_if_not_found=False)
        if not record:
            _logger.warning("signova_ecommerce_theme: xmlid %s not found, skipped.", xmlid)
            continue
        record.write({'website_id': website.id})
        _logger.info("signova_ecommerce_theme: scoped %s to website %s (id=%s)",
                     xmlid, website.name, website.id)
