

def migrate(cr, version):
    from odoo import api, SUPERUSER_ID
    from odoo.addons.signova_ecommerce_theme.hooks import post_init_hook

    if not version:
        return
    env = api.Environment(cr, SUPERUSER_ID, {})
    post_init_hook(env)
