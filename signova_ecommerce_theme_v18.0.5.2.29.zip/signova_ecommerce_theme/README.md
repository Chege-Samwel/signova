# Signova E-commerce Theme

Website-only customizations for the Signova storefront. Same database as
Euromedia, zero shared surface area.

## Install

1. Copy this folder into your Odoo 18 addons path.
2. Update Apps List, search "Signova E-commerce Theme", install.
3. The `post_init_hook` runs automatically and looks up the website whose
   domain contains `signova.store` (falls back to name containing
   "signova"). It then pins every view and asset this module ships to
   that website's `website_id`.
4. If the hook logs a warning saying it couldn't find the website (check
   Settings > Technical > Logging, or the server log), it means your
   Signova website record doesn't have `signova.store` set as its domain
   yet, or is named something else. Set the domain first
   (Website > Configuration > Settings > Website Info, per your screenshot
   this is already done), then either reinstall the module or manually set
   `Website` on each of these 4 records via
   Settings > Technical > User Interface > Views / Assets (enable developer
   mode first):
   - `homepage_signova_banner`
   - `body_signova_class`
   - `shop_signova_grid_tweak`
   - `asset_signova_scss` / `asset_signova_js`

## Verify isolation before you trust it

Don't take "it should be scoped" on faith. Check it:

1. Open the Euromedia website in an incognito tab. Confirm no Signova
   styling, banner, or grid change appears.
2. In developer mode, go to Settings > Technical > Views, filter on this
   module, confirm the `Website` column shows "Signova" on every row, not
   blank.
3. Same check under Settings > Technical > Assets for the two `ir.asset`
   records.
4. Load `/shop` on Euromedia's domain, inspect the page source, confirm
   `theme.scss`/`theme.js` are NOT in the loaded asset bundle list.

If any of those come back wrong, nothing was actually isolated — fix it
before building further on top.

## What this deliberately does NOT do

- Does not touch `website.layout`, `website_sale.products`, or any other
  shared template outside of a scoped `t-if` + `website_id` inheritance.
- Does not override any controller. `website_sale`'s own controllers
  already resolve `request.website` correctly for multi-website —
  rewriting them (as loosely implied by the original plan's controllers/
  folder) is unnecessary and riskier.
- Does not reimplement variant/price switching JS — Odoo's own
  `website_sale` variant mixin already does this correctly out of the box.
- Does not decide product/company scoping for you. That's a real decision
  with inventory/accounting consequences (see below) — it isn't a theme
  concern and shouldn't be bundled into this module.

## The decision this module does NOT make for you

Your screenshot shows products already carrying `Company: SIGNOVA` on the
product form. That's the right instinct for keeping the two catalogs
visually separate in Inventory/Purchase, but confirm explicitly whether
you want:

- **Fully separate catalogs** (Signova products have `company_id` =
  Signova and are only ever sold/purchased under that company), or
- **A shared product catalog** with `website_id` alone controlling what
  each storefront displays, while `company_id` stays blank/shared for
  accounting simplicity.

These are not equivalent, and picking wrong now means a rework later:
company-scoped products can't be sold through the other company's sale
orders without extra multi-company routing, whereas website-scoped-only
products can be shown/hidden per site freely but pool inventory and
accounting. Decide this before you scale past your first ~20 SKUs.

## Extending this module

- Add more `t-if`-guarded inherited templates in
  `views/website_templates.xml` for checkout/cart/product page tweaks.
  Copy the same two-layer pattern (website_id + t-if) for every new view.
- Add snippets under a new `views/snippets.xml`, same rule applies.
- Keep all CSS nested under `.o_signova_theme` in `theme.scss`. Never add
  a bare top-level selector — that's the #1 way this kind of module leaks
  into another website's styling.
