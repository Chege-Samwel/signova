"""Re-run the website scoping after an UPGRADE.

post_init_hook only fires on a fresh install. Without this migration, any
template or asset added in a new version would be created with
website_id = False (i.e. GLOBAL) and would render on the Euromedia
storefront too — exactly what this module exists to prevent.

Odoo runs this automatically when upgrading to 18.0.2.0.0 because the
version in __manifest__.py was bumped.
"""


def migrate(cr, version):
    from odoo import api, SUPERUSER_ID
    from odoo.addons.signova_ecommerce_theme.hooks import post_init_hook

    if not version:
        return
    env = api.Environment(cr, SUPERUSER_ID, {})
    post_init_hook(env)
