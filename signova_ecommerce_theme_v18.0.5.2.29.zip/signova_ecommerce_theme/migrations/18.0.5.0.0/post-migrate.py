def migrate(cr, version):
    # 18.0.5.0.0: ensure new tables exist (signova.faq, signova.product.spec etc are auto-created via models)
    # No data migration needed; FAQs are loaded via data/faqs.xml
    pass
