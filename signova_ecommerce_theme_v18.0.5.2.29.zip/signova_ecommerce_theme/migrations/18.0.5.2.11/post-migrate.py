def migrate(cr, version):
    """
    Post-migration for v18.0.5.2.11 - Ensures seamless upgrade preserves data and scopes correctly.
    
    Runs AFTER new code is loaded, so we can re-scope views to Signova website.
    """
    import logging
    _logger = logging.getLogger(__name__)
    
    _logger.info("=== Signova v18.0.5.2.11 post-migrate: scoping and verification ===")
    
    # Use env to scope records (same logic as hooks.py)
    from odoo import api, SUPERUSER_ID
    env = api.Environment(cr, SUPERUSER_ID, {})
    
    # Find Signova website
    Website = env['website']
    website = Website.search([('domain', 'ilike', 'signova.store')], limit=1)
    if not website:
        website = Website.search([('name', 'ilike', 'signova')], limit=1)
    if not website:
        website = Website.search([], limit=1)
    
    if not website:
        _logger.warning("No website found in post-migrate, skipping scoping")
        return
    
    _logger.info("Found website for scoping: %s (id=%s, domain=%s)", website.name, website.id, website.domain)
    
    # Scope all Signova records to this website
    RECORDS_TO_SCOPE = [
        'homepage_signova_banner',
        'header_signova_signin',
        'body_signova_class',
        'shop_signova_grid_tweak',
        'product_signova_gallery',
        'product_signova_sticky_cta',
        'seo_signova_head',
        'homepage_signova_marketplace',
        'signova_product_card',
        'asset_signova_scss',
        'asset_signova_js',
    ]
    
    MODULE = 'signova_ecommerce_theme'
    scoped = 0
    
    for record_name in RECORDS_TO_SCOPE:
        xmlid = f"{MODULE}.{record_name}"
        record = env.ref(xmlid, raise_if_not_found=False)
        if not record:
            continue
        try:
            if hasattr(record, 'website_id'):
                if record.website_id.id != website.id:
                    record.write({'website_id': website.id})
                    scoped += 1
                    _logger.info("Post-migrate scoped %s to %s", xmlid, website.name)
        except Exception as e:
            _logger.warning("Failed to scope %s in post-migrate: %s", xmlid, e)
    
    _logger.info("Post-migrate scoping complete: %s records scoped to %s", scoped, website.name)
    
    # Verify upgrade preserved data (products, orders)
    try:
        product_count = env['product.template'].search_count([('sale_ok', '=', True)])
        order_count = env['sale.order'].search_count([])
        _logger.info("Data preservation check: %s saleable products, %s orders (should be 30 and 10 if demo data was loaded)", product_count, order_count)
    except Exception as e:
        _logger.warning("Data check failed: %s", e)
    
    _logger.info("=== Post-migrate complete - v18.0.5.2.11 seamless upgrade finished ===")
    _logger.info("Verify: Apps shows v18.0.5.2.11, http://localhost:8069/shop works, no 500 errors")
