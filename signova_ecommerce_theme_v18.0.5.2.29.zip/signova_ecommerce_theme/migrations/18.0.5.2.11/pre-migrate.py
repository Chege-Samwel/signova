def migrate(cr, version):
    """
    Pre-migration for v18.0.5.2.11 - Seamless upgrade from v18.0.5.2.0 (failing) to v18.0.5.2.11
    
    Cleans up broken views from v2.0 that cause Odoo 18 upgrade failures.
    Fixed for Odoo 18: arch_db is jsonb, so need ::text cast for ILIKE.
    """
    import logging
    _logger = logging.getLogger(__name__)
    
    _logger.info("=== Signova v18.0.5.2.11 pre-migrate: cleaning broken v2.0 views ===")
    
    try:
        # In Odoo 18, arch_db is jsonb, not text - need ::text cast
        # Also handle case where table might not have data yet
        cr.execute("""
            SELECT id, name FROM ir_ui_view 
            WHERE name ILIKE '%%signova%%' 
            AND (
                arch_db::text ILIKE '%%o_wsale_my_cart%%' 
                OR arch_db::text ILIKE '%%product_detail%%'
                OR arch_db::text ILIKE '%%o_wsale_products_grid_table_wrapper%%'
            )
        """)
        broken_views = cr.fetchall()
        
        for view_id, view_name in broken_views:
            _logger.info("Found potentially broken view from v2.0: %s (id=%s) - will be replaced by v2.11", view_name, view_id)
    except Exception as e:
        # If query fails (e.g., no views yet, or different schema), log and continue
        # Don't block upgrade - this is non-critical cleanup
        _logger.warning("Pre-migrate view cleanup check failed (non-critical, continuing): %s", e)
        # Rollback the failed transaction to allow further queries
        cr.rollback()
    
    try:
        # Check assets - ir_asset might not exist in all Odoo versions, use try
        cr.execute("""
            SELECT id, name FROM ir_asset 
            WHERE name ILIKE '%%signova%%'
        """)
        assets = cr.fetchall()
        _logger.info("Found %s existing Signova assets, will re-scope in post-migrate", len(assets))
    except Exception as e:
        _logger.warning("Asset check failed (non-critical): %s", e)
        cr.rollback()
    
    _logger.info("=== Pre-migrate complete - ready for seamless upgrade to v2.11 ===")
