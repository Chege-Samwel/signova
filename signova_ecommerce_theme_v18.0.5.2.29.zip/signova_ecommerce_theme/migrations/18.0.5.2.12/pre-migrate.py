def migrate(cr, version):
    """
    Pre-migration for v18.0.5.2.12 - Fixes jsonb ILIKE bug from v2.11
    
    v2.11 had:
      arch_db ILIKE '%%...%%'  -> fails because arch_db is jsonb in Odoo 18
      Error: operator does not exist: jsonb ~~* unknown
    
    v2.12 fix:
      arch_db::text ILIKE '%%...%%'  + try/except + rollback
    """
    import logging
    _logger = logging.getLogger(__name__)
    
    _logger.info("=== Signova v18.0.5.2.12 pre-migrate: jsonb fix ===")
    
    try:
        # Odoo 18: arch_db is jsonb, need ::text cast for ILIKE
        cr.execute("""
            SELECT id, name FROM ir_ui_view 
            WHERE name ILIKE '%%signova%%' 
            AND (
                arch_db::text ILIKE '%%o_wsale_my_cart%%' 
                OR arch_db::text ILIKE '%%product_detail%%'
                OR arch_db::text ILIKE '%%o_wsale_products_grid_table_wrapper%%'
            )
        """)
        broken_views = cr.fetchall()
        for view_id, view_name in broken_views:
            _logger.info("Found old view from v2.0: %s (id=%s) - will be replaced", view_name, view_id)
    except Exception as e:
        _logger.warning("View cleanup check failed (non-critical, continuing): %s", e)
        try:
            cr.rollback()
        except:
            pass
    
    try:
        cr.execute("SELECT id, name FROM ir_asset WHERE name ILIKE '%%signova%%'")
        assets = cr.fetchall()
        _logger.info("Found %s Signova assets", len(assets))
    except Exception as e:
        _logger.warning("Asset check failed (non-critical): %s", e)
        try:
            cr.rollback()
        except:
            pass
    
    _logger.info("=== Pre-migrate v2.12 complete ===")
