def migrate(cr, version):
    import logging
    _logger = logging.getLogger(__name__)
    _logger.info("=== v2.14 post-migrate minimal ===")
