def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.16 pre-migrate: website.page record fix ===")
    try:
        cr.execute("SELECT id FROM ir_ui_view WHERE name ILIKE '%%signova%%' LIMIT 1")
        _logger.info("Found signova views")
    except Exception as e:
        _logger.warning("Check failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
