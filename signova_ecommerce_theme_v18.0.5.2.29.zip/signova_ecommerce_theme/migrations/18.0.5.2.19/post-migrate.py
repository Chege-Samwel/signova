def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.19 post-migrate shop grid fix complete ===")
    # Clear asset cache to force SCSS regeneration
    try:
        cr.execute("DELETE FROM ir_attachment WHERE url LIKE '%%assets_frontend%%' OR url LIKE '%%web.assets%%'")
        _logger.info("Cleared asset attachments to force regeneration")
    except Exception as e:
        _logger.warning("Asset cache clear failed (non-critical): %s", e)
        try:
            cr.rollback()
        except:
            pass
