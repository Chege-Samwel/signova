def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.21 post-migrate shop mirrors New Arrivals ===")
    try:
        cr.execute("DELETE FROM ir_attachment WHERE url LIKE '%%assets_frontend%%'")
    except Exception as e:
        _logger.warning("Clear failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
