def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.21 pre-migrate: shop mirrors New Arrivals ===")
    try:
        cr.execute("SELECT id FROM ir_ui_view WHERE name ILIKE '%%signova%%' LIMIT 1")
    except Exception as e:
        _logger.warning("Check failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
