def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.22 pre-migrate: fix broken xpath ===")
    try:
        # Clean broken view from v2.21 if exists
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Product Item Fix'")
        _logger.info("Cleaned broken view from v2.21")
    except Exception as e:
        _logger.warning("Cleanup failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
    try:
        cr.execute("SELECT id FROM ir_ui_view WHERE name ILIKE '%%signova%%' LIMIT 1")
    except Exception as e:
        _logger.warning("Check failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
