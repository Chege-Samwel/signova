def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.24 post-migrate SCSS fixed ===")
    try:
        cr.execute("DELETE FROM ir_attachment WHERE url LIKE '%%assets_frontend%%' OR url LIKE '%%web.assets%%'")
        _logger.info("Cleared all asset attachments to force regeneration")
    except Exception as e:
        _logger.warning("Clear failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
