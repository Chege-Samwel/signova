def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.25 pre-migrate: fix vertical text + gold icons ===")
    try:
        cr.execute("SELECT id FROM ir_ui_view WHERE name ILIKE '%%signova%%' LIMIT 1")
    except Exception as e:
        _logger.warning("Check failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
