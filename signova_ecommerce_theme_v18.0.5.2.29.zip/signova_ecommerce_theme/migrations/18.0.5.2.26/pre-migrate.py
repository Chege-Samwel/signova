def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.26 pre-migrate: preserve colours + fix vertical ===")
    try:
        # Clean old marketplace views that leak to shop (without path check)
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Marketplace Landing' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Marketplace Landing' GROUP BY name)")
        _logger.info("Cleaned duplicate marketplace views")
    except Exception as e:
        _logger.warning("Cleanup failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
    try:
        cr.execute("SELECT id FROM ir_ui_view WHERE name ILIKE '%%signova%%' LIMIT 1")
    except Exception as e:
        _logger.warning("Check failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
