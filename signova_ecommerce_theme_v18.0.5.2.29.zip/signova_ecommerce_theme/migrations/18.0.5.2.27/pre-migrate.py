def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.27 pre-migrate: shop mirrors New Arrivals ===")
    try:
        # Clean duplicate views that leak to shop
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Marketplace Landing' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Marketplace Landing' GROUP BY name)")
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Homepage Hero' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Homepage Hero' GROUP BY name)")
        _logger.info("Cleaned duplicates")
    except Exception as e:
        _logger.warning("Cleanup failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
