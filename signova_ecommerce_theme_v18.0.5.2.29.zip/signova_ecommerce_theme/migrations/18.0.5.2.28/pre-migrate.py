def migrate(cr, version):
    import logging
    _logger=logging.getLogger(__name__)
    _logger.info("=== v2.28 pre-migrate: fix vertical + 0 count + leak ===")
    try:
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Marketplace Landing' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Marketplace Landing' GROUP BY name)")
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Homepage Hero' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Homepage Hero' GROUP BY name)")
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Product Card' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Product Card' GROUP BY name)")
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Products Item Fix' AND id NOT IN (SELECT MAX(id) FROM ir_ui_view WHERE name='Signova Products Item Fix' GROUP BY name)")
        cr.execute("DELETE FROM ir_ui_view WHERE name='Signova Product Item Fix'")
        _logger.info("Cleaned duplicates and broken views")
    except Exception as e:
        _logger.warning("Cleanup failed: %s", e)
        try:
            cr.rollback()
        except:
            pass
