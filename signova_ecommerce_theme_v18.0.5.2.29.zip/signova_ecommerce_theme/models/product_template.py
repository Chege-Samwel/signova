# -*- coding: utf-8 -*-
from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    # --- Signova extensive data (for easy website expansion) ---
    # These fields are *additive* — they do not override core Odoo fields,
    # so the module remains compatible with the base v18.0.1.0.0.

    signova_short_desc = fields.Text(
        string="Card short description (≤120 chars)",
        help="Shown on product cards, flash rail, related grid. Keep under 60 chars for best truncation. Used if set, else falls back to short_desc."
    )
    signova_long_desc = fields.Html(
        string="Detailed description (website)",
        help="Full HTML for product page Description tab. Supports internal links to /shop?cat=, /product/, /blog/, /page/. Seed with 150–300 words."
    )
    signova_specs_json = fields.Text(
        string="Specifications (JSON)",
        help='JSON dict, e.g. {"Thickness": "3 mm", "Size": "8×4 ft", "Material": "Cast acrylic"}. Rendered as table. Keep keys short.'
    )
    signova_care_instructions = fields.Html(string="Care & warranty")
    signova_delivery_note = fields.Html(string="Delivery note (overrides default)")
    signova_keywords = fields.Char(string="SEO keywords (comma)")
    signova_seo_title = fields.Char(string="SEO title (≤60 chars)")
    signova_seo_desc = fields.Char(string="SEO meta (≤160 chars)")
    signova_extra_sku_note = fields.Char(string="SKU note / internal ref")

    signova_product_spec_ids = fields.One2many('signova.product.spec', 'product_tmpl_id', string="Structured specs")
    signova_faq_ids = fields.One2many('signova.product.faq', 'product_tmpl_id', string="FAQs")

    # helper to expose specs as dict for QWeb
    def _signova_specs_dict(self):
        self.ensure_one()
        import json
        try:
            if self.signova_specs_json:
                return json.loads(self.signova_specs_json)
            # fallback to structured specs
            return {s.name: s.value for s in self.signova_product_spec_ids}
        except Exception:
            return {}

class SignovaProductSpec(models.Model):
    """Optional normalized specs table — use JSON above for quick edits, or this model for bulk UI."""
    _name = 'signova.product.spec'
    _description = 'Signova Product Spec (key/value)'

    product_tmpl_id = fields.Many2one('product.template', string="Product", required=True, ondelete='cascade')
    name = fields.Char(string="Spec name", required=True)  # e.g. Thickness
    value = fields.Char(string="Spec value", required=True)  # e.g. 3 mm
    sequence = fields.Integer(default=10)

class SignovaProductFaq(models.Model):
    _name = 'signova.product.faq'
    _description = 'Product FAQ (for FAQPage schema)'

    product_tmpl_id = fields.Many2one('product.template', string="Product", ondelete='cascade')
    website_id = fields.Many2one('website', string="Website")
    question = fields.Char(required=True)
    answer = fields.Html(required=True)
    sequence = fields.Integer(default=10)

class SignovaFaq(models.Model):
    _name = 'signova.faq'
    _description = 'Signova General FAQ (for FAQPage schema, 30)'

    question = fields.Char(required=True)
    answer = fields.Html(required=True)
    website_id = fields.Many2one('website', string="Website")
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
