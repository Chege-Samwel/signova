/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

// ---------------------------------------------------------------------
// NOTE: Do not reimplement variant/price switching here. Odoo's
// website_sale already updates price and stock live when a customer
// changes an attribute (see website_sale's own "WebsiteSaleVariantMixin").
// Re-writing that logic duplicates behaviour Odoo already ships correctly
// and gives you a second place to have bugs.
//
// Everything below is pure presentation, and every selector is prefixed
// with .o_signova_theme so it can only ever run on the Signova site.
// ---------------------------------------------------------------------

/**
 * Reveals a sticky "Add to Cart" bar once the real button scrolls
 * out of view. The bar's button is a plain anchor back to #add_to_cart —
 * it does not submit the cart form itself, on purpose.
 */
publicWidget.registry.SignovaStickyAddToCart = publicWidget.Widget.extend({
    selector: ".o_signova_theme #product_detail, .o_signova_theme .o_wsale_product_page",

    start() {
        this._super(...arguments);

        this.addToCartBtn = this.el.querySelector("#add_to_cart");
        this.stickyBar = this.el.querySelector(".o_signova_sticky_bar");

        if (!this.addToCartBtn || !this.stickyBar) {
            return Promise.resolve();
        }

        // IntersectionObserver is cheaper and smoother than a scroll handler.
        if ("IntersectionObserver" in window) {
            this.observer = new IntersectionObserver(
                (entries) => {
                    for (const entry of entries) {
                        this.el.classList.toggle(
                            "o_signova_sticky_cta",
                            !entry.isIntersecting
                        );
                    }
                },
                { rootMargin: "0px", threshold: 0 }
            );
            this.observer.observe(this.addToCartBtn);
        } else {
            this._boundScroll = () => this._onScroll();
            window.addEventListener("scroll", this._boundScroll, { passive: true });
            this._onScroll();
        }

        return Promise.resolve();
    },

    destroy() {
        if (this.observer) {
            this.observer.disconnect();
        }
        if (this._boundScroll) {
            window.removeEventListener("scroll", this._boundScroll);
        }
        this._super(...arguments);
    },

    _onScroll() {
        const rect = this.addToCartBtn.getBoundingClientRect();
        const outOfView = rect.bottom < 0 || rect.top > window.innerHeight;
        this.el.classList.toggle("o_signova_sticky_cta", outOfView);
    },
});

/**
 * Smooth-scrolls in-page anchor links (used by the sticky bar and the
 * hero buttons when they point at an on-page target).
 */
publicWidget.registry.SignovaSmoothAnchor = publicWidget.Widget.extend({
    selector: ".o_signova_theme",
    events: {
        "click .o_signova_sticky_link": "_onAnchorClick",
    },

    _onAnchorClick(ev) {
        const href = ev.currentTarget.getAttribute("href") || "";
        if (!href.startsWith("#") || href.length < 2) {
            return;
        }
        const target = document.querySelector(href);
        if (!target) {
            return;
        }
        ev.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "center" });
    },
});


/**
 * WhatsApp order — page-specific custom messages + flow + animations
 * - Product page: includes name, SKU, qty, URL
 * - Cart page: includes all lines + total
 * - Any page: floating WA button with pulse
 */
publicWidget.registry.SignovaWhatsApp = publicWidget.Widget.extend({
    selector: ".o_signova_theme",
    events: {
        "click .js-wa-product": "_onWaProduct",
        "click .js-wa-cart": "_onWaCart",
        "click .js-wa-faq": "_onWaGeneral",
    },
    _onWaProduct(ev){
        ev.preventDefault();
        const btn = ev.currentTarget;
        const name = btn.dataset.name || document.querySelector("h1")?.textContent?.trim() || "Product";
        const sku = btn.dataset.sku || "";
        const slug = btn.dataset.slug || location.pathname;
        const qtyEl = document.querySelector("#add_to_cart_qty, #qty, input[name='add_qty']");
        const qty = qtyEl ? qtyEl.value : "1";
        const url = location.origin + slug;
        const msg = `Hi Signova, I want to order ${name}${sku?` (SKU: ${sku})`:''} Qty: ${qty} — ${url} — Page: ${location.href}`;
        window.open("https://wa.me/97441492333?text=" + encodeURIComponent(msg), "_blank");
        // animation: button pulse
        btn.classList.add("wa-pulse");
        setTimeout(()=> btn.classList.remove("wa-pulse"), 600);
    },
    _onWaCart(ev){
        ev.preventDefault();
        const lines = [...document.querySelectorAll(".oe_cart .product-name, .cart_line")].map(el=> el.textContent.trim()).filter(Boolean);
        let msg = "Hi Signova, I want to order my cart:\n" + (lines.join("\n") || "Cart from " + location.href);
        const tot = document.querySelector(".order_total, .oe_cart .monetary_field, .csum .tot b");
        if(tot) msg += "\nTotal: " + tot.textContent.trim();
        msg += "\nPage: " + location.href;
        window.open("https://wa.me/97441492333?text=" + encodeURIComponent(msg), "_blank");
    },
    _onWaGeneral(ev){
        ev.preventDefault();
        const page = document.title || location.pathname;
        const msg = `Hi Signova, I have a question about ${page} — ${location.href}`;
        window.open("https://wa.me/97441492333?text=" + encodeURIComponent(msg), "_blank");
    }
});

/**
 * Mobile filter drawer — collapsible, optimized for mobile (fix 7)
 */
publicWidget.registry.SignovaMobileFilters = publicWidget.Widget.extend({
    selector: ".o_signova_theme .o_wsale_products_page, .o_signova_theme .o_signova_shop_wrap",
    start(){
        this._super(...arguments);
        this.btn = this.el.querySelector(".js-filter-toggle");
        this.side = this.el.querySelector(".o_wsale_products_grid_before_rail, .o_signova_side");
        this.overlay = this.el.querySelector(".o_signova_shop_overlay");
        if(!this.btn || !this.side) return Promise.resolve();
        this.btn.addEventListener("click", ()=> this._toggle());
        this.overlay?.addEventListener("click", ()=> this._toggle(false));
        return Promise.resolve();
    },
    _toggle(force){
        const open = typeof force==="boolean" ? force : !this.side.classList.contains("open");
        this.side.classList.toggle("open", open);
        this.overlay?.classList.toggle("show", open);
        this.btn.setAttribute("aria-expanded", open?"true":"false");
        document.body.style.overflow = open ? "hidden" : "";
    }
});

/**
 * Shop category hide/unhide accordion — auto-hide on select + back-button scroll restoration (fix 8)
 * - Click parent with subs: expands/collapses without navigation (first tap)
 * - Click leaf or second tap on parent: navigates via fetch + pushState, no full reload, auto-hides drawer
 * - popstate restores scroll without reload
 */
publicWidget.registry.SignovaCatAccordion = publicWidget.Widget.extend({
    selector: ".o_signova_theme .o_wsale_products_page, .o_signova_theme .o_signova_shop_wrap",
    start(){
        this._super(...arguments);
        this.grid = this.el.querySelector(".o_wsale_products_grid, .o_signova_prail, .grid4");
        if(!this.grid) return Promise.resolve();
        this._bindCats();
        window.addEventListener("popstate", (e)=> this._onPop(e));
        return Promise.resolve();
    },
    _bindCats(){
        this.el.querySelectorAll("[data-cat-group]").forEach(group=>{
            const parent = group.querySelector(".cat-parent");
            const subs = group.querySelector(".cat-subs");
            if(!parent || !subs) return;
            parent.addEventListener("click", (ev)=>{
                const isOpen = group.classList.contains("open");
                // first tap on parent with subs expands, does not navigate
                if(!isOpen){
                    ev.preventDefault();
                    this.el.querySelectorAll(".cat-group.open").forEach(g=>{
                        if(g!==group){ g.classList.remove("open"); const s=g.querySelector(".cat-subs"); if(s) s.style.display="none"; }
                    });
                    group.classList.add("open");
                    subs.style.display="block";
                    return false;
                }
                // second tap navigates via AJAX
            });
        });
        this.el.querySelectorAll("[data-cat-link]").forEach(a=>{
            a.addEventListener("click", (ev)=> this._onCatClick(ev));
        });
    },
    _onCatClick(ev){
        const a = ev.currentTarget;
        // if parent with closed subs, let it expand first (handled above)
        const group = a.closest("[data-cat-group]");
        if(group && a.classList.contains("cat-parent")){
            const subs = group.querySelector(".cat-subs");
            if(subs && !group.classList.contains("open")){
                return; // already prevented above
            }
        }
        // AJAX navigation with history + scroll restoration
        if(window.history && window.fetch && a.href && a.href.includes("/shop")){
            ev.preventDefault();
            const href = a.href;
            const state = {url: location.href, scrollY: window.scrollY};
            history.replaceState(state, "", location.href);
            this._loadShop(href, true);
            // auto-hide drawer on mobile
            const side = document.querySelector(".o_wsale_products_grid_before_rail, .o_signova_side");
            const overlay = document.querySelector(".o_signova_shop_overlay");
            if(side && side.classList.contains("open")){
                side.classList.remove("open");
                overlay?.classList.remove("show");
                document.body.style.overflow="";
            }
            return false;
        }
    },
    _loadShop(url, push){
        const grid = this.grid;
        fetch(url, {headers:{"X-Requested-With":"fetch"}}).then(r=> r.text()).then(html=>{
            const doc = new DOMParser().parseFromString(html, "text/html");
            const newGrid = doc.querySelector(".o_wsale_products_grid, .o_signova_prail, .grid4");
            const newChips = doc.querySelector(".subchips, .o_wsale_categories_top");
            const curChips = document.querySelector(".subchips, .o_wsale_categories_top");
            if(newGrid) grid.innerHTML = newGrid.innerHTML;
            if(newChips){
                if(curChips) curChips.innerHTML = newChips.innerHTML;
                else {
                    const head = document.querySelector(".shophead, .o_wsale_products_header");
                    if(head) head.insertAdjacentHTML("afterend", newChips.outerHTML);
                }
            } else if(curChips) curChips.remove();
            // update active
            document.querySelectorAll("[data-cat-link]").forEach(el=> el.classList.remove("on"));
            const u = new URL(url, location.origin);
            const cat = u.searchParams.get("cat") || "all";
            document.querySelectorAll(`[data-cat="${cat}"]`).forEach(el=> el.classList.add("on"));
            // update accordion open
            document.querySelectorAll("[data-cat-group]").forEach(g=>{
                const slug = g.getAttribute("data-cat-group");
                const isActive = slug===cat;
                g.classList.toggle("open", isActive);
                const s = g.querySelector(".cat-subs");
                if(s) s.style.display = isActive ? "block" : "none";
            });
            if(push) history.pushState({url:url, scrollY:0}, "", url);
            window.scrollTo({top:0, behavior:"smooth"});
            // toast if available
            if(window.toast) toast("Category updated");
        }).catch(()=> location.href=url);
    },
    _onPop(e){
        if(e.state && e.state.url){
            this._loadShop(e.state.url, false);
            setTimeout(()=> window.scrollTo(0, e.state.scrollY||0), 50);
        }
    }
});

/**
 * FAQ flow — accordion animation, deep-link via hash, FAQPage schema already in DOM
 */
publicWidget.registry.SignovaFaq = publicWidget.Widget.extend({
    selector: ".o_signova_faq, .o_signova_theme .faq-list",
    start(){
        this._super(...arguments);
        // open hash if present
        if(location.hash){
            const el = document.querySelector(location.hash);
            if(el && el.tagName==="DETAILS") el.open=true;
        }
        this.el.querySelectorAll("details").forEach(d=>{
            d.addEventListener("toggle", ()=>{
                d.classList.toggle("open", d.open);
                if(d.open) history.replaceState(null, "", "#" + (d.id || ""));
            });
        });
        return Promise.resolve();
    }
});

export default publicWidget.registry.SignovaStickyAddToCart;

/**
 * Countdown timer for the deal band. Counts down to the end of the
 * current week (Sunday 23:59), then rolls over — no server field needed.
 * Scoped to .o_signova_theme like everything else in this file.
 */
publicWidget.registry.SignovaCountdown = publicWidget.Widget.extend({
    selector: ".o_signova_theme [data-signova-countdown]",

    start() {
        this._super(...arguments);
        this.fields = {
            days: this.el.querySelector('[data-cd="days"]'),
            hours: this.el.querySelector('[data-cd="hours"]'),
            mins: this.el.querySelector('[data-cd="mins"]'),
            secs: this.el.querySelector('[data-cd="secs"]'),
        };
        if (!this.fields.secs) {
            return Promise.resolve();
        }
        this._tick();
        this.interval = setInterval(() => this._tick(), 1000);
        return Promise.resolve();
    },

    destroy() {
        if (this.interval) {
            clearInterval(this.interval);
        }
        this._super(...arguments);
    },

    _tick() {
        const now = new Date();
        const end = new Date(now);
        end.setDate(now.getDate() + (7 - now.getDay()) % 7);
        end.setHours(23, 59, 59, 999);

        let diff = Math.max(0, Math.floor((end - now) / 1000));
        const d = Math.floor(diff / 86400); diff -= d * 86400;
        const h = Math.floor(diff / 3600);  diff -= h * 3600;
        const m = Math.floor(diff / 60);
        const s = diff - m * 60;

        const pad = (n) => String(n).padStart(2, "0");
        this.fields.days.textContent = pad(d);
        this.fields.hours.textContent = pad(h);
        this.fields.mins.textContent = pad(m);
        this.fields.secs.textContent = pad(s);
    },
});

/**
 * Hero slider — image-only 1900x550, 8 slides, autoplay, dots + arrows, touch.
 * Scoped to .o_signova_theme.
 */
publicWidget.registry.SignovaHeroSlider = publicWidget.Widget.extend({
    selector: ".o_signova_theme .s_signova_hero_slider",
    start() {
        this._super(...arguments);
        this.track = this.el.querySelector(".s_signova_hero_track");
        this.dots = [...this.el.querySelectorAll(".s_signova_hero_dot")];
        this.slides = [...this.el.querySelectorAll(".s_signova_hero_slide")];
        if (!this.track || !this.slides.length) return Promise.resolve();
        this.idx = 0;
        this.total = this.slides.length;
        this._bind();
        this._go(0);
        this._auto();
        return Promise.resolve();
    },
    destroy(){ this._stop(); this._super(...arguments); },
    _bind(){
        this.el.querySelector(".s_signova_hero_arrow.prev")?.addEventListener("click", ()=> this._step(-1));
        this.el.querySelector(".s_signova_hero_arrow.next")?.addEventListener("click", ()=> this._step(1));
        this.dots.forEach((d,i)=> d.addEventListener("click", ()=> this._go(i)));
        this.el.addEventListener("mouseenter", ()=> this._stop());
        this.el.addEventListener("mouseleave", ()=> this._auto());
        let sx=0;
        this.el.addEventListener("touchstart", e=>{ sx=e.touches[0].clientX; this._stop(); }, {passive:true});
        this.el.addEventListener("touchend", e=>{
            const dx=e.changedTouches[0].clientX - sx;
            if(Math.abs(dx)>40) this._step(dx<0?1:-1); else this._auto();
        });
    },
    _go(i){ this.idx=(i+this.total)%this.total; this.track.style.transform=`translateX(-${this.idx*100}%)`; this.dots.forEach((d,j)=> d.classList.toggle("on", j===this.idx)); },
    _step(d){ this._go(this.idx+d); this._auto(); },
    _auto(){ this._stop(); this.timer=setInterval(()=> this._go(this.idx+1), 4500); },
    _stop(){ if(this.timer) clearInterval(this.timer); }
});

/**
 * Product gallery — multi-image with autoplay, thumbs, zoom lightbox.
 * Does NOT interfere with Odoo's variant image switching; it only enhances
 * the main image container if extra images are present.
 */
publicWidget.registry.SignovaGallery = publicWidget.Widget.extend({
    selector: ".o_signova_theme #product_detail, .o_signova_theme .o_wsale_product_page",
    start(){
        this._super(...arguments);
        this.mainImg = this.el.querySelector(".o_wsale_product_images img, #product_detail_main img");
        this.thumbs = [...this.el.querySelectorAll(".o_signova_thumb")];
        this.lightbox = document.querySelector(".o_signova_lightbox");
        if(!this.mainImg || this.thumbs.length<2) return Promise.resolve();
        this.imgs = this.thumbs.map(t=> t.dataset.src || t.querySelector("img")?.src);
        this.idx=0;
        this.thumbs.forEach((t,i)=> t.addEventListener("click", ()=> this._to(i)));
        this.el.querySelector(".o_signova_gallery_nav.prev")?.addEventListener("click", ()=> this._to(this.idx-1));
        this.el.querySelector(".o_signova_gallery_nav.next")?.addEventListener("click", ()=> this._to(this.idx+1));
        this.mainImg.style.cursor="zoom-in";
        this.mainImg.addEventListener("click", ()=> this._open());
        this.lightbox?.addEventListener("click", ()=> this._close());
        document.addEventListener("keydown", e=>{ if(e.key==="Escape") this._close(); });
        this._auto();
        this.el.addEventListener("mouseenter", ()=> this._stop());
        this.el.addEventListener("mouseleave", ()=> this._auto());
        return Promise.resolve();
    },
    destroy(){ this._stop(); this._super(...arguments); },
    _to(i){
        this.idx=(i+this.imgs.length)%this.imgs.length;
        this.mainImg.src=this.imgs[this.idx];
        this.thumbs.forEach((t,j)=> t.classList.toggle("on", j===this.idx));
        this._auto();
    },
    _auto(){ this._stop(); if(this.imgs.length>1) this.timer=setInterval(()=> this._to(this.idx+1), 2800); },
    _stop(){ if(this.timer) clearInterval(this.timer); },
    _open(){
        if(!this.lightbox) return;
        this.lightbox.querySelector("img").src=this.imgs[this.idx];
        this.lightbox.classList.add("show");
    },
    _close(){ this.lightbox?.classList.remove("show"); }
});
